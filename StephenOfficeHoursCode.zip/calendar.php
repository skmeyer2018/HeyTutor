<!DOCTYPE html>
<HTML>
<BODY>
<CENTER>
<H1>Office Hours Sign Up</H1>
</CENTER>
<FORM method="POST" >
Student Name:<input type="text" name="studentName" id="studentName" required size="50">
Student Email:<input type="text" name="studentEmail" id="studentEmail" required size="50">
<input type="submit" value="Submit">
<input type="reset" value="Clear">

<br>
<?php

$m=date('m',strtotime("This month"));
$dateObj=DateTime::createFromFormat('!m',$m);
$monthName = $dateObj->format('F');

$weekdays=array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");

//THE MONTH AND YEAR SECTION
echo "<div style='width:100%;font-weight:bold;font-size:25px;'>";
echo "<center><p style='color:white;background-color:rgb(0,255,0);padding:25px;'>".$monthName.' '.date('Y')."</p>";

//THE WEEKDAYS
for($i=0; $i<count($weekdays); $i++)
{
  echo "<div style='display:inline;padding-right:158px;padding-top:30px;padding-bottom:30px;background-color:rgb(220,220,220);border-color:white;border-style:solid;'>".substr($weekdays[$i],0,3)."</div>";

}

echo "</div>";

echo "<div style='width:100%;padding-top:50px;font-weight:bold;font-size:25px;'>";
$day1=strtotime("first day of this month");
$weekday1=date('l',$day1);
$dayLast=strtotime("last day of this month");
$maxDate=(int)date('d',$dayLast);
$dateCount=0;

//GENERATE THE CALENDAR DATES
$hoursNotice="";
for ($r=1; $r<=4; $r++)
{
 echo "<div style='width:100%;height:90px;font-weight:bold;font-size:25px;'>";
 for ($c=1; $c<=7; $c++)
 {
   
    echo "<div style='display:inline;width:75px;padding-right:175px;height:90px;padding-bottom:90px;overflow-x:auto;white-space:nowrap;background-color:rgb(220,220,220);border-color:white;border-style:solid;'>";
    $doc='<input type="radio" name="choice"'.$dateCount.' id="choice" value="A"><label for="choice">A</label>';
    
    //echo "<iframe srcdoc='".$doc."' width='10%' height='25px'>";
   if ($dateCount == 0)
     {
        if ($weekdays[$c-1] == $weekday1)
          echo str_pad(strval($dateCount++),2,'_');
        else
            {
               echo str_pad(strval($dateCount),2,'_'); 
               echo "</div>";
               ++$dateCount; 
              continue;
            }
      }
   
    if ($dateCount > 10)
      echo $dateCount++;
    else
      {
        if ($dateCount > 0)
      		echo str_pad(strval($dateCount++),2,'_');
      }
   //PUT THE HOURS IN
    if ($c>=2 && $c <=6)
     {
       if(isset($_POST[$weekdays[$c-1].'Hours']))
        {
 
          echo "<font size='2'>";
	  for ($h=0; $h<count($_POST[$weekdays[$c-1].'Hours']); $h++)
	   {

                echo "<input type='radio' name='hourSet".strval($dateCount)."' id='hourSet".strval($dateCount)."' value='".$_POST[$weekdays[$c-1].'Hours'][$h]."'>";
                echo "<label for='hourSet".strval($dateCount)."'>".$_POST[$weekdays[$c-1].'Hours'][$h]."</label>";
                echo "<input type='hidden' name='txtHourSet".strval($dateCount).strval($h)."' value='".$_POST[$weekdays[$c-1].'Hours'][$h]."'>";

            }
            echo "&nbsp;".$weekdays[$c-1];
            echo "</font>";

        }
        else
         {
 
          if(isset($_POST['hourSet'.strval($dateCount)]))
          {

              $h=0;
             while(isset($_POST['txtHourSet'.strval($dateCount).strval($h)]))
             {

                 echo "<font size='2'>";
                 echo "<input type='radio' name='hourNotSelected' id='hourNotSelected' value='".$_POST['txtHourSet'.strval($dateCount).strval($h)]."'>";
                  echo "<label for='hourNotSelected'>".$_POST['txtHourSet'.strval($dateCount).strval($h)]."</label>";
                  if ($_POST['txtHourSet'.strval($dateCount).strval($h)] == $_POST['hourSet'.strval($dateCount)])  
                   {
                      echo $_POST['studentName'];
                      $hoursNotice .= $_POST['hourSet'.strval($dateCount)]."\n\r";
                    }	
                 echo "</font>";
                ++$h;

             }
         
          }
         }

     }
    //echo "<select>";
   echo "</div>";

 }
 echo "</div>";
}
//A FEW MORE DAYS AT THE BOTTOM OF THE CALENDAR
while ($dateCount < $maxDate)
{
 echo "<div style='width:100%;height:90px;font-weight:bold;font-size:25px;'>";
 for ($c=1; $c<=7; $c++)
 {
    echo "<div style='display:inline;padding-right:175px;padding-bottom:50px;background-color:rgb(220,220,220);border-color:white;border-style:solid;'>";
 
    if ($dateCount <= $maxDate)
    {
       echo $dateCount++;
    }
    else
      echo str_pad('*',2,'_'); 
     echo "</div>";
 }
 echo "</div>";

}

echo "</div>";
if (isset($_POST['studentName']))
{
 //ini_set("SMTP","smtp.mail.yahoo.com");
// ini_set("smtp_port",465);
// ini_set('sendmail_from', 'skmeyer2014@gmail.com');
 $body=$_POST['studentName']."\n\r".$hoursNotice;
 mail($_POST['studentEmail'],$_POST['studentName']." hours",$body);
}

?>

</FORM>
</BODY>
</HTML>