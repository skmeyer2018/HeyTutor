<!DOCTYPE html>
<HTML>
<HEAD>
<TITLE>Office Hours Setup Form</TITLE>
<center><H1>Office Hours Setup Form</H1></center>
<STYLE>
 tr,td{background-color:rgb(230,230,230);}
 td {padding:80px;}
</STYLE>
</HEAD>
<BODY>
<center><p style="font-size:20px;">NOTE: to select several hours within a time list in a day column, hold the 'CTRL' key</p></center>
<FORM method='POST' action='calendar.php'> <!-- method='POST' action='calendar.php'-->
<TABLE >
<TR>
<TH>
Day
</TH>
<?php
$weekdays=array("Monday","Tuesday","Wednesday","Thursday","Friday");
for ($i=0; $i<count($weekdays); $i++)
{
  echo "<TH>".$weekdays[$i]."</TH>";

}

?>

</TR>
<TR>
<TD style="font-weight:bold;">
Time
</TD>
<?php
for ($i=0; $i<count($weekdays); $i++)
{
  echo "<TD><SELECT name='".$weekdays[$i]."Hours[]' multiple='multiple' size=12>";
  for ($amHours=7; $amHours<12; $amHours++)
   {
     echo "<option  value='".$amHours.":00am'>".$amHours.":00am</option>";
     echo "<option  value='".$amHours.":30am'>".$amHours.":30am</option>";

   }
   echo "<option value='12:00pm'>12:00pm</option>";
   echo "<option  value='12:30pm'>12:30pm</option>";
  for ($pmHours=1; $pmHours<=10; $pmHours++)
   {
     echo "<option  value='".$pmHours.":00pm'>".$pmHours.":00pm</option>";
     if ($pmHours < 10)
      echo "<option  value='".$pmHours.":30pm'>".$pmHours.":30pm</option>";

   }
  echo "</TD>";
}


?>
</TR>


</TABLE>
<CENTER>
<input type="reset" value="Clear">
<input type="submit" value="Submit">
</CENTER>
</FORM>
</BODY>
</HTML>