<center><h1>ONLINE QUIZ</h1></center>
<?php
class QAPair
{
    public $theQuestion;
    public $theCorrectAnswer;
}
$questionsFile = fopen("Questions.txt","r");
$quiz[]=new QAPair();
$i=0;
error_reporting(E_ERROR | E_PARSE);
while(! feof($questionsFile))
{
 $quest=fgets($questionsFile);
 $correctAnswer=fgets($questionsFile);
 $quiz[$i]->theQuestion=trim($quest);
 $quiz[$i]->theCorrectAnswer=trim($correctAnswer);
 ++$i;
}
$numberOfQuestions=$i-1;
fclose($questionsFile);
$answerSets=Array();
$answersFile=fopen("Answers.txt","r");
$i=0;
while(! feof($answersFile))
{
  $answerSets[$i]=fgets($answersFile);
  ++$i;

}
echo "<form method='post'>";
for ($i=0; $i<count($quiz); $i++)
{
    echo "<h2>". $quiz[$i]->theQuestion . "</h2>";
    $multChoice=explode("|",$answerSets[$i]);
    for ($j=0; $j<count($multChoice); $j++)
    {
      echo "<input type='radio' id='choice".$i.$j."' name='ques".$i."'  value='".$multChoice[$j]."' >";
      echo "<label for='choice$i$j' >".$multChoice[$j]. "<br>";
    }
   // echo "correct answer  ". $quiz[$i]->theCorrectAnswer . "<br>";
}
echo "<input type='submit' value='SUBMIT'><br>";
echo "</form>";
$score=0;
for ($i=0; $i<count($quiz); $i++)
{
  $selectedAnswer= $_POST['ques'.$i];
  if ($selectedAnswer == $quiz[$i]->theCorrectAnswer)
  {
    ++$score;

  }
}
if (isset($numberOfQuestions))
{
  $finalScore=($score/$numberOfQuestions) * 100;
  echo "You have got ".$score." answers right<br>";
  $scoreColor="";
  if ($finalScore >= 80)
  {
    $scoreColor="green";
  }
 elseif ($finalScore >= 60)
  {
    $scoreColor="green";
  }
  elseif ($finalScore >= 50)
  {
    $scoreColor="red";
  }
  else 
  {
    $scoreColor="black";
  }  
  echo "<p style='color:".$scoreColor.";'>your final score is ". $finalScore."%</p><br>";
}

?>
