<?php
class UserComment
{
    public $userName;
    public $userEmail;
    public $userComment;
}
echo "<h1>COMMENTS</h1>";
$commentsFile = fopen("UserComments.txt","r");
$theUser[]=new UserComment();
$i=0; 
clearstatcache();
error_reporting(E_ERROR | E_PARSE);

while(! feof($commentsFile))
  {
     try 
     {
      error_reporting(E_ERROR | E_PARSE);
      $readUserName=fgets($commentsFile);
      if ($readUserName == NULL || trim($readUserName) == "" || !($readUserName) || empty($readUserName) || feof($commentsFile)) break;
      $theUser[$i]->userName=trim($readUserName);
      $readEmail=fgets($commentsFile);
      $theUser[$i]->userEmail=trim($readEmail);
      $readUserComment=fgets($commentsFile);;
      $theUser[$i]->userComment=trim($readUserComment);    
      ++$i;
     }
     catch (Exception $e)
     {

     }
 
  }
  if ($i == 0)
  { 
    echo "<p><b>NO COMMENTS MADE ABOUT THIS POST</b></p>";
    fclose($commentsFile);
    echo '<center><a href="EnterComment.html">(Back to ADD COMMENT page)</a></center>';
    exit ();
  }  
     fclose($commentsFile);
    echo "<p><b>READING COMMENTS FROM TEXT FILE:</b></p>";
    echo "<hr>";
    echo "<ol>";
   for ($i=0; $i<count($theUser); $i++)
   {
       echo "<b><li>NAME:</b>" .$theUser[$i]->userName. "<br>";
      echo "<b>COMMENT:</b>" .$theUser[$i]->userComment." </li>";
      echo "<hr>";
   }
   echo "</ol>";
   $conn=mysqli_connect("127.0.0.1","root","");
   mysqli_query($conn,"USE usercomments");
   $selectAll=mysqli_query($conn,"SELECT * FROM users");
   $rows=mysqli_num_rows($selectAll);
   echo "<p><b>READING COMMENTS FROM DATABASE:</b></p>";
   echo "<hr>";
   echo "<ol>";
  
 
   while ($rows = mysqli_fetch_row($selectAll)) {
    echo "<b><li>NAME:</b>" .$rows[0]. "<br>";
    echo "<b>COMMENT:</b>" .$rows[2]." </li>";
    echo "<hr>";  
  
  }
  

   echo '<center>';
   echo '<a href="SortAZ.php">Sort Comments A-Z (by name)</a><br>';
   echo '<a href="SortZA.php">Sort Comments Z-A (by name)</a><br>';
 
    echo '<a href="EnterComment.html">(Back to ADD COMMENT page)</a>';
    echo '</center>';
 

?>