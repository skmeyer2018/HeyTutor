<?php
$userName=$_POST["userName"];
$userEmail=$_POST["userEmail"];
$userComment=$_POST["userComment"];
error_reporting(E_ERROR | E_PARSE);
clearstatcache();
if (file_exists("UserComments.txt") == FALSE)
{
  $commentsFile = fopen("UserComments.txt","a");
  fclose($commentsFile);
  echo "file now created";
}
$commentsFile = fopen("UserComments.txt","r");
while(! feof($commentsFile)) //SEE IF THE PERSON PREVIOUSLY COMMENTED
  {
    $readLine=fgets($commentsFile);
    $readLine=trim($readLine);
    if ($readLine == $userName)//THE USER COMMENTED BEFORE, NO NEED TO HEAR FROM THEM AGAIN
    {
        echo "<h1>Cannot add your comment!</h1>";
        echo "<p style='font-size:20px;font-weight:bold;'>Only one comment allowed per user.  You already submitted your comment for this posting!</p>";
        fclose($commentsFile);
        echo '<center><a href="EnterComment.html">(Back to ADD COMMENT page)</a></center>';
        exit();
    }
  }

//OTHERWISE POPULATE THE FILE AND DATABASE WITH USER NAME, EMAIL AND COMMENT
$commentsFile=fopen("UserComments.txt","a");
fwrite($commentsFile,$userName."\n");
fwrite($commentsFile,$userEmail."\n");
fwrite($commentsFile,$userComment."\n");
fclose($commentsFile);
echo "<center>";
echo "<p>Your comment was successfully added to the text file</p>";
$conn=mysqli_connect("127.0.0.1","root","");
if($conn)
{
  echo "MySQL connection successful.";
  mysqli_query($conn,"USE usercomments");
  mysqli_query($conn, "INSERT INTO users (UserName, Email, Comments) VALUES ('$userName','$userEmail','$userComment')");
  echo "<p>and to the database too.</p>";
}
else
{
  echo "SORRY, connection failed!";
}

echo "Thank you, $userName for your comment:<br>";
echo $userComment;
echo "</center>";

?>
<center><a href="EnterComment.html">(Back to ADD COMMENT page)</a></center>