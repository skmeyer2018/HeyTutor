<?php
class UserComment
{
    public $userName;
    public $userEmail;
    public $userComment;
}
$commentsFile = fopen("UserComments.txt","r");
$theUser=array();
$i=0; 
 
//READ FILE AND JOIN EACH OF THE USER COMMENT GROUPINGS WITH THE PIPE | SYMBOL
while(! feof($commentsFile))
  {
     try 
     {
      error_reporting(E_ERROR | E_PARSE);
      $readUserName=fgets($commentsFile);
      if ($readUserName == NULL || trim($readUserName) == "" || !($readUserName) || empty($readUserName) || feof($commentsFile)) break;
      $theUser[$i]=trim($readUserName);
      $readEmail=fgets($commentsFile);
      $theUser[$i].= "|".trim($readEmail);
      $readUserComment=fgets($commentsFile);
      $theUser[$i].="|".trim($readUserComment); 
      ++$i;
     }
     catch (Exception $e)
     {
        echo $e;
        fclose($commentsFile);
     }
 
  }
  fclose($commentsFile);
  sort($theUser);
  //SORT THE JOINED GROUPINGS SO THAT THE BY THE SORTED NAMES THE EMAIL AND COMMENT ARE IN THE ORDER CORRESPONDING TO THE NAME
  $sortedUser[]=new UserComment();
  $commentsFile = fopen("UserComments.txt","w");
  echo "<p><b>READING COMMENTS FROM TEXT FILE:</b></p>";
  echo "<hr>";
  echo "<ol>";
 for($i=0; $i<count($theUser); $i++)
  { //HERE THE SORTED JOINED GROUPING IS NOW SPLIT IN ITS OWN ARRAY, SO THAT THE SORTED USER OBJECT GETS ITS OWN NAME
    //WITH THE CORRESPONDING EMAIL AND COMMENT
     $userTempString=explode("|",$theUser[$i]);
     $sortedUser[$i]->userName=$userTempString[0]; 
     $sortedUser[$i]->userEmail=$userTempString[1];
     $sortedUser[$i]->userComment=$userTempString[2];
     echo "<b><li>NAME:</b>".$sortedUser[$i]->userName."<br>";
     echo "<b>COMMENT:</b>".$sortedUser[$i]->userComment."</li>";
     echo "<hr>";
     fwrite($commentsFile,$sortedUser[$i]->userName."\n");
     fwrite($commentsFile,$sortedUser[$i]->userEmail."\n");
     fwrite($commentsFile,$sortedUser[$i]->userComment."\n");
  }
  echo "</ol>";
  fclose($commentsFile);
  $maxNumberOfComments=0;
   //THIS LOOP ADDITIONALLY COUNTS THE NUMBER OF COMMENTS TO THE MAX VALUE
   //TO PREVENT THE USER FROM ENTERING A NUMBER OF OUT RANGE 
   //SHOULD THE USER WANT TO DELETE A COMMENT
  $conn=mysqli_connect("127.0.0.1","root","");
  mysqli_query($conn,"USE usercomments");
  $selectAll=mysqli_query($conn,"SELECT * FROM users ORDER BY UserName");
  $rows=mysqli_num_rows($selectAll);
  echo "<p><b>READING COMMENTS FROM DATABASE SORTED BY NAME ASCENDING ORDER:</b></p>";
  echo "<hr>";
  echo "<ol>"; 
  while ($rows = mysqli_fetch_row($selectAll)) {
   echo "<b><li>NAME:</b>" .$rows[0]. "<br>";
   echo "<b>COMMENT:</b>" .$rows[2]." </li>"; 
   echo "<hr>";
   ++$maxNumberOfComments; 
 }
 echo "</ol>";
 echo '<center>';
 echo '<form method="post"';
 echo '<p><b>Delete comment number:</b></p>';
 echo '<input type="number" name="deleteNumber" value="1" min="1" max="'.$maxNumberOfComments.'"><BR>';
 echo '<input type="SUBMIT" value="SUBMIT"><BR>';
 echo '</form><BR>';
 $deleteNumber=-1;
 if( isset($_POST["deleteNumber"]))
 {
   $deleteNumber=$_POST["deleteNumber"] - 1;
   echo "Do you want to delete this comment, numbered " . ($deleteNumber + 1) . "? <br>";

   echo "NAME:" . $sortedUser[$deleteNumber]->userName. "<br> COMMENT: " . $sortedUser[$deleteNumber]->userComment . "<br>";
   echo "<form method='post'>";
   echo "<input type='radio' id='yes' name='wantDelete' value='yes'>";
   echo "<label for='yes'>YES</label><br>";
   echo "<input type='radio' id='no' name='wantDelete' value='no'>";
   echo "<label for='no'>NO</label><br>";
   echo "<input type='hidden' name='deleteNumber' value='".$deleteNumber."'>";
   echo "<input type='submit' value='SUBMIT'><br>";
   echo "</form>";

 }
 if (isset($_POST['wantDelete']))
 {
    if($_POST['wantDelete'] == 'yes')
    {
      $deleteNumber=(int)$_POST['deleteNumber'];

      $commentsFile = fopen("UserComments.txt","w");
       for ($i=0; $i<count($sortedUser); $i++)
       {
          if ($i == $deleteNumber)
            continue;
         else
         {
            fwrite($commentsFile,$sortedUser[$i]->userName."\n");
            fwrite($commentsFile,$sortedUser[$i]->userEmail."\n");
            fwrite($commentsFile,$sortedUser[$i]->userComment."\n");
          }  
       }
       fclose($commentsFile);
       $deleteQuery="DELETE FROM users where UserName='".$sortedUser[$deleteNumber]->userName."'";
       $deleteFromDB= mysqli_query($conn,$deleteQuery);
       header("Location: EnterComment.html");
    }

 }
 echo '<a href="EnterComment.html">(Back to ADD COMMENT page)</a></center>';

?>